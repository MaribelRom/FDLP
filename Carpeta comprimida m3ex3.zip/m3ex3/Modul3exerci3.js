
let nota1=prompt("Escribe nota Primera Evaluación","")
let nota2=prompt("Escribe nota Segunda Evaluación","")
let nota3=prompt("Escribe nota Tercera Evaluación","")
nota1=Number(nota1)
nota2=Number(nota2)
nota3=Number(nota3)

let resultMedia=(parseInt (nota1)+parseInt (nota2)+parseInt (nota3))/3

alert("la media es:" + resultMedia)



