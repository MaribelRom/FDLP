function numPar(){
    let num=Number (prompt("Dime un numero y te diré si es par o impar"))
    if (num %2==0) {
        alert (`"El número ${num} es par"`)
    }
    else{
        alert (`"El número ${num} es impar"`)
    }
}