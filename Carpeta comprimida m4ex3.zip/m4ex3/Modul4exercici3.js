 function getBeca(){
        let ageUsuari = Number(prompt("Indica els anys que tens",""))
        let universityUsuari = prompt("Tens un títol universitari?","si o no")
        let aturUsuari = prompt ("Estas a l'atur?","si o no")
    if (ageUsuari >=18 && universityUsuari ==="si") {
     alert("Tens dret a beca")
    }

   else if(aturUsuari ==="si") {
    alert("Tens dret a beca")
   }
   else {
    alert("No tens dret a beca")
   }
    }

    



 



/*
if (edat>=18){
    alert("Tienes derecho a una beca")
}
if (universitat==="si"){
 alert("Tienes derecho a una beca") 
 }  

if (atur==="si"){
    alert("Tienes derecho a una beca")
}*/
    
