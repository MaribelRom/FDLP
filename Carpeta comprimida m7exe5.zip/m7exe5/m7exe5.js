function showNumbers() {
 let i=100
  for (i=100;i>=0; i--){
    if(i%2==0){
    document.write (i + "</br>")
    
    } 
  }
}





     

